% =========================================================================
% Propeller Optimizer (MATLAB Port)
% Based on Blade Element Momentum Theory (BEMT)
% Calculates Induced and Profile Power/Drag separately.
% =========================================================================

function PropellerOptimizer()
    % 1. Configuration & Constants
    config.filename = '5-cruise_Geometry.txt';
    
    % Physical Constants
    phys.D = 0.25;              % Diameter [m]
    phys.R = phys.D / 2.0;
    phys.Z = 5;                 % Number of Blades
    phys.rho = 1.225;           % Density [kg/m^3]
    phys.V_inf = 20.0;          % Inflow Velocity [m/s]
    phys.Target_Thrust = 37.0;  % Target Thrust [N]
    phys.Cd_base = 0.008;       % Base drag coefficient
    phys.Stall_Angle = 15.0;    % Stall limit [deg]
    phys.Max_RPM = 100000.0;     % Maximum RPM limit

    % 2. Load Geometry
    if ~isfile(config.filename)
        fprintf(2, 'Error: File "%s" not found.\n', config.filename);
        return;
    end
    
    geom = parse_openprop_geometry_robust(config.filename);
    
    if isempty(geom.r_R)
        fprintf(2, 'Error: No valid geometry data loaded.\n');
        return;
    end

    % 3. Pre-Process Geometry
    % Convert normalized coordinates to physical units
    geom.radius = geom.r_R .* phys.R;
    % Handle r=0 case to avoid division by zero
    geom.radius(geom.radius == 0) = 1e-6; 
    
    geom.chord = geom.c_D .* phys.D;
    geom.beta_geom_rad = deg2rad(geom.pitch_deg);
    
    % Calculate Zero Lift Angle from Camber (NACA a=0.8 meanline approximation)
    % Cli = f0/c / 0.0679
    geom.Cli = geom.f0_c ./ 0.0679;
    geom.alpha_L0 = -geom.Cli ./ (2 * pi);

    % 4. Optimization Routine
    fprintf('Optimizing for Minimum Total Drag Force at %.1f m/s for %.1f N...\n', ...
            phys.V_inf, phys.Target_Thrust);
    fprintf('Constraint: Max RPM = %.0f\n', phys.Max_RPM);

    % Define Objective Function for Pitch Shift Optimization
    % We search for the Delta_Beta (pitch shift) that minimizes Total Drag Force
    % while maintaining the Target Thrust (by adjusting RPM inside).
    obj_fun = @(db) calculate_obj(db, geom, phys);
    
    options = optimset('Display', 'off', 'TolX', 1e-4);
    
    % Bounded minimization (equivalent to scipy minimize_scalar)
    % Searching pitch shift between -60 and +10 degrees
    [opt_shift, min_drag, exitflag] = fminbnd(obj_fun, -60, 10, options);

    if exitflag > 0
        % Recalculate final state
        rpm_opt = find_rpm_robust(opt_shift, geom, phys);
        
        if isnan(rpm_opt)
             fprintf('Optimization converged on pitch, but valid RPM not found within limit (%.0f).\n', phys.Max_RPM);
        else
            final = evaluate_propeller(rpm_opt, opt_shift, geom, phys);
            print_results(rpm_opt, opt_shift, final, phys, geom);
        end
    else
        fprintf('Optimization failed to converge.\n');
    end
end

% =========================================================================
% Core Solver Logic
% =========================================================================

function cost = calculate_obj(delta_beta_deg, geom, phys)
    % Finds RPM for thrust, returns Total Drag Force (cost)
    rpm = find_rpm_robust(delta_beta_deg, geom, phys);
    if isnan(rpm)
        cost = 1e9; % Penalty for invalid state
    else
        res = evaluate_propeller(rpm, delta_beta_deg, geom, phys);
        % Cost is Total Equivalent Drag Force = (Induced Power + Profile Power) / V_inf
        cost = (res.induced_power + res.profile_power) / phys.V_inf;
    end
end

function rpm = find_rpm_robust(delta_beta_deg, geom, phys)
    % Root finder to get RPM that matches Target Thrust
    
    target_T = phys.Target_Thrust;
    
    % Error function: Calc_Thrust - Target_Thrust
    err_func = @(r) get_thrust_error(r, delta_beta_deg, geom, phys, target_T);
    
    % Scan ranges to bracket the root, respecting Max_RPM
    % Split search space to handle multiple roots or complexity
    mid_point = phys.Max_RPM / 2;
    ranges = [100, mid_point; mid_point, phys.Max_RPM];
    
    rpm = NaN;
    
    for i = 1:size(ranges, 1)
        low = ranges(i, 1);
        high = ranges(i, 2);
        
        try
            f_low = err_func(low);
            f_high = err_func(high);
            
            % If sign changes, root is in between
            if f_low * f_high < 0
                % Use fzero (Brent's method)
                rpm = fzero(err_func, [low, high]);
                return;
            end
        catch
            continue;
        end
    end
    
    % Fallback: scalar minimization of squared error if bracketing fails
    if isnan(rpm)
        sq_err = @(r) err_func(r)^2;
        % Constrain fallback search to Max_RPM
        rpm = fminbnd(sq_err, 100, phys.Max_RPM);
        if sq_err(rpm) > 1.0 % If error is still too high (couldn't reach thrust within RPM limit)
             rpm = NaN;
        end
    end
end

function err = get_thrust_error(rpm, db, geom, phys, target)
    res = evaluate_propeller(rpm, db, geom, phys);
    if isempty(res)
        err = -1e5;
    else
        err = res.thrust - target;
    end
end

function results = evaluate_propeller(rpm, delta_beta_deg, geom, phys)
    % Integrates forces over the blade span
    
    if rpm <= 0
        results = [];
        return;
    end
    
    omega = rpm * 2 * pi / 60.0;
    delta_beta_rad = deg2rad(delta_beta_deg);
    
    n_pts = length(geom.radius);
    
    % Pre-allocate arrays
    dT = zeros(n_pts, 1);
    dQ = zeros(n_pts, 1);
    dP_ind = zeros(n_pts, 1);
    dP_prof = zeros(n_pts, 1);
    ua = zeros(n_pts, 1);
    ut = zeros(n_pts, 1);
    beta_i = zeros(n_pts, 1);
    beta_flow = zeros(n_pts, 1);
    cl_arr = zeros(n_pts, 1);
    cd_arr = zeros(n_pts, 1);
    gam_arr = zeros(n_pts, 1);
    alpha_arr = zeros(n_pts, 1);
    
    % Solve for each radial section
    for i = 1:n_pts
        res = solve_section(geom.radius(i), geom.chord(i), ...
            geom.beta_geom_rad(i), geom.alpha_L0(i), ...
            omega, phys.V_inf, delta_beta_rad, phys);
        
        dT(i) = res.dT;
        dQ(i) = res.dQ;
        dP_ind(i) = res.dP_induced;
        dP_prof(i) = res.dP_profile;
        ua(i) = res.u_a;
        ut(i) = res.u_t;
        beta_i(i) = res.beta_i;
        beta_flow(i) = res.beta;
        cl_arr(i) = res.cl;
        cd_arr(i) = res.cd;
        gam_arr(i) = res.gamma;
        alpha_arr(i) = res.alpha;
    end
    
    % Integration (Trapezoidal Rule)
    % Multiply by Z (number of blades)
    results.thrust = trapz(geom.radius, dT) * phys.Z;
    results.torque = trapz(geom.radius, dQ) * phys.Z;
    
    % Power breakdown
    results.induced_power = trapz(geom.radius, dP_ind) * phys.Z;
    results.profile_power = trapz(geom.radius, dP_prof) * phys.Z;
    
    % Total Power (Torque * Omega) - Should roughly equal Ind + Prof
    results.power = results.torque * omega;
    
    % Mass Flow Rate Integration (Global annulus, do not multiply by Z)
    % dm_dot = rho * (V + ua) * 2 * pi * r
    dm_dot = phys.rho .* (phys.V_inf + ua) .* 2 .* pi .* geom.radius;
    results.mass_flow = trapz(geom.radius, dm_dot);
    
    % Store sectional details
    results.details.gam = gam_arr;
    results.details.ua = ua;
    results.details.ut = ut;
    results.details.beta = beta_flow;
    results.details.beta_i = beta_i;
    results.details.cl = cl_arr;
    results.details.cd = cd_arr;
    results.details.alpha = alpha_arr;
end

function sec = solve_section(r, c, beta_orig, alpha_L0, omega, V_inf, delta_beta_rad, phys)
    % Iterative BEMT Solver for a single section
    
    beta_new = beta_orig + delta_beta_rad;
    
    % Initial Guess
    u_axial = 0.0;
    u_tang = 0.0;
    
    CL_MAX = 1.4;
    
    % Relaxation loop
    for iter = 1:20
        % 1. Flow State
        V_axial_eff = V_inf + u_axial;
        V_tang_eff = omega * r - u_tang;
        
        % Check overflow
        if abs(V_axial_eff) > 1000 || abs(V_tang_eff) > 1000
            V_res_sq = 1e6;
        else
            V_res_sq = V_axial_eff^2 + V_tang_eff^2;
        end
        
        phi = atan2(V_axial_eff, V_tang_eff);
        
        % 2. Aerodynamics
        alpha_rad = beta_new - phi - alpha_L0;
        alpha_deg = rad2deg(alpha_rad);
        
        % Linear Lift
        cl_linear = 2 * pi * alpha_rad;
        
        % Soft CL cap
        if abs(cl_linear) > CL_MAX
            cl = sign(cl_linear) * (CL_MAX + 0.1 * tanh(abs(cl_linear) - CL_MAX));
        else
            cl = cl_linear;
        end
        
        % Drag with stall penalty
        cd = phys.Cd_base;
        if abs(alpha_deg) > phys.Stall_Angle || abs(cl_linear) > CL_MAX
            excess_angle = max(0, abs(alpha_deg) - phys.Stall_Angle);
            excess_cl = max(0, abs(cl_linear) - CL_MAX);
            cd = phys.Cd_base + 0.02 * excess_angle^2 + 0.5 * excess_cl^2;
        end
        
        % Forces PER BLADE unit span
        lift = 0.5 * phys.rho * V_res_sq * c * cl;
        drag = 0.5 * phys.rho * V_res_sq * c * cd;
        
        dT_blade = lift * cos(phi) - drag * sin(phi);
        dF_tang_blade = lift * sin(phi) + drag * cos(phi);
        dQ_blade = dF_tang_blade * r;
        
        % 3. Momentum Update
        dT_total = dT_blade * phys.Z;
        dQ_total = dQ_blade * phys.Z;
        
        % Calculate u_a from Thrust
        denom_mom = 4 * pi * r * phys.rho;
        K_thrust = dT_total / denom_mom;
        
        if K_thrust > 0
            u_axial_new = (-V_inf + sqrt(V_inf^2 + 4 * K_thrust)) / 2;
        elseif K_thrust > -(V_inf^2)/4
            u_axial_new = (-V_inf + sqrt(max(0, V_inf^2 + 4 * K_thrust))) / 2;
        else
            u_axial_new = -0.5 * V_inf;
        end
        
        % Calculate u_t from Torque
        m_dot_annulus = phys.rho * (V_inf + u_axial) * 2 * pi * r;
        if m_dot_annulus > 1e-6
            u_tang_new = dQ_total / (2 * m_dot_annulus * r);
        else
            u_tang_new = 0.0;
        end
        
        % Relaxation
        diff_a = u_axial_new - u_axial;
        diff_t = u_tang_new - u_tang;
        
        step_limit = 5.0;
        if abs(diff_a) > step_limit, diff_a = sign(diff_a) * step_limit; end
        if abs(diff_t) > step_limit, diff_t = sign(diff_t) * step_limit; end
        
        f = 0.3; % Relaxation factor
        u_axial = u_axial + f * diff_a;
        u_tang = u_tang + f * diff_t;
        
        if abs(diff_a) < 0.01 && abs(diff_t) < 0.01
            break;
        end
    end
    
    % Final Recalculation
    V_res_eff = sqrt((V_inf + u_axial)^2 + (omega * r - u_tang)^2);
    phi = atan2(V_inf + u_axial, omega * r - u_tang);
    
    alpha_rad = beta_new - phi - alpha_L0;
    
    % Recalc CL/CD
    cl_linear = 2 * pi * alpha_rad;
    if abs(cl_linear) > CL_MAX
        cl = sign(cl_linear) * (CL_MAX + 0.1 * tanh(abs(cl_linear) - CL_MAX));
    else
        cl = cl_linear;
    end
    
    alpha_deg = rad2deg(alpha_rad);
    cd = phys.Cd_base;
    if abs(alpha_deg) > phys.Stall_Angle || abs(cl_linear) > CL_MAX
        excess_angle = max(0, abs(alpha_deg) - phys.Stall_Angle);
        excess_cl = max(0, abs(cl_linear) - CL_MAX);
        cd = phys.Cd_base + 0.02 * excess_angle^2 + 0.5 * excess_cl^2;
    end
    
    lift = 0.5 * phys.rho * V_res_eff^2 * c * cl;
    drag = 0.5 * phys.rho * V_res_eff^2 * c * cd;
    
    dT_blade = lift * cos(phi) - drag * sin(phi);
    dF_tang_blade = lift * sin(phi) + drag * cos(phi);
    
    % Power Components (Work done on fluid vs Work done on friction)
    dP_induced_blade = dT_blade * u_axial + dF_tang_blade * u_tang;
    dP_profile_blade = drag * V_res_eff;
    
    % Pack results
    sec.dT = dT_blade;
    sec.dQ = dF_tang_blade * r;
    sec.dP_induced = dP_induced_blade;
    sec.dP_profile = dP_profile_blade;
    sec.u_a = u_axial;
    sec.u_t = u_tang;
    sec.beta_i = rad2deg(phi);
    sec.beta = rad2deg(atan2(V_inf, omega*r));
    sec.cl = cl;
    sec.cd = cd;
    sec.gamma = 0.5 * V_res_eff * c * cl;
    sec.alpha = alpha_deg;
end

% =========================================================================
% File Parsing & Utilities
% =========================================================================

function geom = parse_openprop_geometry_robust(filename)
    fprintf('DEBUG: Attempting to parse %s...\n', filename);
    
    fid = fopen(filename, 'r');
    if fid == -1
        geom = struct('r_R', [], 'c_D', [], 'pitch_deg', [], 'f0_c', []);
        return;
    end
    
    r_R = []; c_D = []; pitch = []; f0_c = [];
    
    header_found = false;
    col_map = containers.Map('KeyType', 'char', 'ValueType', 'double');
    
    while ~feof(fid)
        line = strtrim(fgetl(fid));
        if isempty(line), continue; end
        
        % Detect Header
        if contains(line, 'r/R') && contains(line, 'c/D')
            header_found = true;
            headers = strsplit(line);
            fprintf('DEBUG: Header found.\n');
            
            for i = 1:length(headers)
                h = headers{i};
                if contains(h, 'r/R'), col_map('r_R') = i;
                elseif contains(h, 'c/D'), col_map('c_D') = i;
                elseif contains(lower(h), 'pitch') && ~contains(lower(h), 'deg'), col_map('pitch') = i;
                elseif contains(h, 'f0/c') || contains(h, 'fo/C'), col_map('f0_c') = i;
                end
            end
            continue;
        end
        
        if header_found
            if contains(line, 'deg'), continue; end % Skip units line
            
            parts = strsplit(line);
            % Try parsing
            try
                idx_r = 1; % Default
                if isKey(col_map, 'r_R'), idx_r = col_map('r_R'); end
                
                if idx_r > length(parts), continue; end
                
                val_r = str2double(parts{idx_r});
                if isnan(val_r), continue; end
                
                % Defaults for others
                idx_c = 2; idx_p = 6; idx_f = 4;
                if isKey(col_map, 'c_D'), idx_c = col_map('c_D'); end
                if isKey(col_map, 'pitch'), idx_p = col_map('pitch'); end
                if isKey(col_map, 'f0_c'), idx_f = col_map('f0_c'); end
                
                val_c = 0; val_p = 0; val_f = 0;
                
                if idx_c <= length(parts), val_c = str2double(parts{idx_c}); end
                if idx_p <= length(parts), val_p = str2double(parts{idx_p}); end
                if idx_f <= length(parts), val_f = str2double(parts{idx_f}); end
                
                r_R(end+1) = val_r; %#ok<AGROW>
                c_D(end+1) = val_c; %#ok<AGROW>
                pitch(end+1) = val_p; %#ok<AGROW>
                f0_c(end+1) = val_f; %#ok<AGROW>
                
            catch
                continue;
            end
        end
    end
    
    fclose(fid);
    
    geom.r_R = r_R';
    geom.c_D = c_D';
    geom.pitch_deg = pitch';
    geom.f0_c = f0_c';
    
    fprintf('DEBUG: Parsed %d rows of geometry data.\n', length(geom.r_R));
end

function print_results(rpm, shift, final, phys, geom)
    n_rps = rpm / 60.0;
    Eta = (final.thrust * phys.V_inf) / final.power;
    
    induced_drag = final.induced_power / phys.V_inf;
    profile_drag = final.profile_power / phys.V_inf;
    
    fprintf('================================================================================\n');
    fprintf(' OPTIMIZED MINIMUM DRAG CONFIGURATION \n');
    fprintf('================================================================================\n');
    fprintf('Required Speed:        %.1f RPM\n', rpm);
    fprintf('Optimal Pitch Shift:   %.4f deg\n', shift);
    fprintf('Efficiency:            %.4f (%.2f%%)\n', Eta, Eta*100);
    fprintf('--------------------------------------------------------------------------------\n');
    fprintf('Thrust Produced:       %.2f N\n', final.thrust);
    fprintf('Total Power:           %.2f W\n', final.power);
    fprintf(' - Induced Power:      %.2f W  (Drag due to Lift)\n', final.induced_power);
    fprintf('   > Induced Drag:     %.2f N\n', induced_drag);
    fprintf(' - Profile Power:      %.2f W  (Drag due to Friction)\n', final.profile_power);
    fprintf('   > Profile Drag:     %.2f N\n', profile_drag);
    fprintf('Mass Flow Rate:        %.2f kg/s\n', final.mass_flow);
    fprintf('Total Equiv. Drag:     %.2f N\n', induced_drag + profile_drag);
    fprintf('================================================================================\n');
    fprintf('SECTIONAL DATA:\n');
    fprintf('%-6s %-9s %-6s %-6s %-8s %-8s %-7s %-7s %-6s %-6s %-6s %-6s\n', ...
            'r/R', 'G', 'Va', 'Vt', 'Ua', 'Ut', 'Beta', 'BetaI', 'c/D', 'CL', 'Cd', 'Alpha');
    fprintf('-------------------------------------------------------------------------------------------------\n');
    
    d = final.details;
    for i = 1:length(geom.r_R)
        fprintf('%-6.4f %-9.5f %-6.1f %-6.1f %-8.4f %-8.4f %-7.2f %-7.2f %-6.4f %-6.3f %-6.4f %-6.2f\n', ...
            geom.r_R(i), d.gam(i), phys.V_inf, 0.0, d.ua(i), -d.ut(i), ...
            d.beta(i), d.beta_i(i), geom.c_D(i), d.cl(i), d.cd(i), d.alpha(i));
    end
end