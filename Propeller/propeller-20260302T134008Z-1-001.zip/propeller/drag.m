%% Propeller BEMT Analysis (Robust Version)
% Matches OpenProp Results by reading dynamic RPM and Geometry
% Calculates Kt, Ct, Thrust, and Drag Components


%% 1. CONFIGURATION
rho = 0.905;  % Fluid Density [kg/m^3]

% File Names
file_geom = '5-cruise_Geometry.txt';
file_perf = '5-cruise_Performance.txt';
file_out  = '5-cruise_Output.txt';

%% 2. DATA IMPORT
fprintf('--- READING DATA ---\n');

% --- A. Read Geometry (D, Z, RPM, Table) ---
[geom_data, D, Z, RPM] = read_geometry_file(file_geom);
r_geom = geom_data(:, 1); % r/R
c_geom = geom_data(:, 2); % c/D

fprintf('Geometry: D=%.2f m, Z=%d, RPM=%.0f\n', D, Z, RPM);

% --- B. Read Performance (V*, Beta, BetaI, CL) ---
perf_data = read_openprop_table(file_perf, 'r/R', 8); 
% Columns: 1:r/R, 2:V*, 3:beta, 4:betai, 6:CL
r_perf = perf_data(:, 1);
V_star = perf_data(:, 2);
beta   = perf_data(:, 3);
betai  = perf_data(:, 4);
CL     = perf_data(:, 6);

% --- C. Read Output (Cd, Js) ---
[out_data, Js] = read_output_file(file_out);
% Columns: 1:r/R, 11:Cd
r_out = out_data(:, 1);
Cd    = out_data(:, 11);

if Js == 0, Js = 1.6; fprintf('Warning: Js not found, using 1.6\n'); end
fprintf('Operating Point: Js = %.4f\n', Js);

%% 3. INTERPOLATION
% Interpolate Performance/Output data to the 21 Geometry Stations

% Use 'extrap' to handle the hub (0.1) and tip (1.0)
V_star_i = interp1(r_perf, V_star, r_geom, 'linear', 'extrap');
beta_i   = interp1(r_perf, beta,   r_geom, 'linear', 'extrap');
betai_i  = interp1(r_perf, betai,  r_geom, 'linear', 'extrap');
CL_i     = interp1(r_perf, CL,     r_geom, 'linear', 'extrap');

% Cd is usually constant or step-wise, use nearest or linear
Cd_i     = interp1(r_out, Cd,      r_geom, 'nearest', 'extrap');

%% 4. BEMT CALCULATIONS
n = RPM / 60;        % rev/s
R = D / 2;           % Radius [m]
r = r_geom * R;      % Radial stations [m]
c = c_geom * D;      % Chord length [m]

% Convert angles to radians
beta_rad  = deg2rad(beta_i);
betai_rad = deg2rad(betai_i);
alpha_i   = betai_rad - beta_rad;

% --- Sectional Forces (per unit length N/m) ---
% dL = 0.5 * rho * V*^2 * CL * c
dL_dr = 0.5 * rho .* (V_star_i.^2) .* CL_i .* c;

% dDp = 0.5 * rho * V*^2 * Cd * c
dDp_dr = 0.5 * rho .* (V_star_i.^2) .* Cd_i .* c;

% dDi = dL * sin(alpha_i)
dDi_dr = dL_dr .* sin(alpha_i);

% Thrust Component: dT = dL*cos(betaI) - dDp*sin(betaI)
dT_dr = dL_dr .* cos(betai_rad) - dDp_dr .* sin(betai_rad);

% --- Integration (Trapezoidal) ---
% Integrate over radius r, then multiply by number of blades Z
T_net     = Z * trapz(r, dT_dr);
D_profile = Z * trapz(r, dDp_dr);
D_induced = Z * trapz(r, dDi_dr);

% --- Coefficients ---
% Standard Kt = T / (rho * n^2 * D^4)
Kt = T_net / (rho * n^2 * D^4);

% OpenProp Ct = Kt * 8 / (pi * Js^2)
Ct = Kt * 8 / (pi * Js^2);

%% 5. DISPLAY RESULTS
fprintf('\n=======================================================\n');
fprintf('                BEMT ANALYSIS RESULTS                  \n');
fprintf('=======================================================\n');
fprintf('Reference: %.0f RPM, rho=%.3f kg/m^3\n', RPM, rho);
fprintf('-------------------------------------------------------\n');
fprintf('Thrust Coefficient (Kt):       %.4f  [Matches OpenProp]\n', Kt);
fprintf('Thrust Loading (Ct):           %.4f  [Matches OpenProp]\n', Ct);
fprintf('-------------------------------------------------------\n');
fprintf('Net Thrust (T):                %.2f N\n', T_net);
fprintf('Total Profile Drag:            %.2f N\n', D_profile);
fprintf('Total Induced Drag:            %.2f N\n', D_induced);
fprintf('-------------------------------------------------------\n');

% Display Table
fprintf('\n--- Detailed Sectional Forces (N/m) ---\n');
fprintf('%-8s %-10s %-10s %-10s %-10s\n', 'r/R', 'V*(m/s)', 'dT/dr', 'dDi/dr', 'dDp/dr');
for i = 1:length(r_geom)
    fprintf('%-8.4f %-10.1f %-10.2f %-10.3f %-10.3f\n', ...
        r_geom(i), V_star_i(i), dT_dr(i), dDi_dr(i), dDp_dr(i));
end

%% =======================================================
%  HELPER FUNCTIONS (Parsers)
%  =======================================================

function [data, D, Z, RPM] = read_geometry_file(filename)
    fid = fopen(filename, 'r');
    if fid == -1, error('Cannot open %s', filename); end
    
    D = 0; Z = 0; RPM = 0; data = [];
    
    while ~feof(fid)
        line = fgetl(fid);
        % Read Metadata
        if contains(line, 'Propeller Diameter')
            D = sscanf(extractAfter(line, '='), '%f');
        elseif contains(line, 'Number of Blades')
            Z = sscanf(extractAfter(line, '='), '%f');
        elseif contains(line, 'Propeller Speed')
            RPM = sscanf(extractAfter(line, '='), '%f');
        end
        
        % Read Table
        if contains(line, 'r/R') && contains(line, 'c/D')
            data = scan_numeric_block(fid, 8);
            break;
        end
    end
    fclose(fid);
end

function [data, Js] = read_output_file(filename)
    fid = fopen(filename, 'r');
    if fid == -1, error('Cannot open %s', filename); end
    
    Js = 0; data = [];
    
    while ~feof(fid)
        line = fgetl(fid);
        if contains(line, 'Js') && contains(line, '=')
            Js = sscanf(extractAfter(line, '='), '%f');
        end
        if contains(line, 'r/R') && contains(line, 'Cd')
            data = scan_numeric_block(fid, 11);
            break;
        end
    end
    fclose(fid);
end

function data = read_openprop_table(filename, header_key, num_cols)
    fid = fopen(filename, 'r');
    if fid == -1, error('Cannot open %s', filename); end
    data = [];
    while ~feof(fid)
        line = fgetl(fid);
        if contains(line, header_key)
            data = scan_numeric_block(fid, num_cols);
            break;
        end
    end
    fclose(fid);
end

function data = scan_numeric_block(fid, num_cols)
    % Helper: Skips non-numeric lines (units) then reads data
    pos = ftell(fid);
    while ~feof(fid)
        line = fgetl(fid);
        [val, count] = sscanf(line, '%f', 1);
        if count == 1
            % Found the start of data, rewind
            fseek(fid, pos, 'bof');
            % Read data block
            fmt = repmat('%f ', 1, num_cols);
            raw = textscan(fid, fmt);
            % Convert cell to matrix
            min_len = min(cellfun(@length, raw));
            data = zeros(min_len, num_cols);
            for c = 1:num_cols
                data(:,c) = raw{c}(1:min_len);
            end
            return;
        end
        pos = ftell(fid);
    end
    data = [];
end